package com.waraqati.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Exam bodies encrypted at rest using an Android Keystore AES/GCM key (not exportable). */
internal class EncryptedExamStore(context: Context) {
    private val dir = File(context.filesDir, "exam_sealed").apply { mkdirs() }
    private val alias = "waraqati_local_exam_key_v1"
    private val maxBytes = 10 * 1024 * 1024

    private fun secret(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getKey(alias, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build())
        return generator.generateKey()
    }
    private fun fileFor(id: String): File {
        require(id.length in 1..128 && id.none { it.code < 32 })
        val digest = MessageDigest.getInstance("SHA-256").digest(id.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return File(dir, "$digest.enc")
    }
    @Synchronized fun saveBase64(encoded: String): Boolean { return try {
        if (encoded.length > maxBytes * 2) return false
        val payload = Base64.decode(encoded, Base64.DEFAULT)
        if (payload.size !in 2..maxBytes) return false
        val id = JSONObject(String(payload, Charsets.UTF_8)).getString("id")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secret())
        val iv = cipher.iv
        val result = byteArrayOf(1, iv.size.toByte()) + iv + cipher.doFinal(payload)
        val dest = fileFor(id)
        val temp = File(dir, dest.name + ".pending")
        temp.outputStream().use { it.write(result); it.fdSyncIfPossible() }
        if (!temp.renameTo(dest)) {
            temp.delete()
            return false
        }
        true
    } catch (_: Exception) { false }
    }

    private fun java.io.OutputStream.fdSyncIfPossible() {
        if (this is java.io.FileOutputStream) fd.sync()
    }

    @Synchronized fun allBase64(): String = try {
        val items=JSONArray()
        for (file in dir.listFiles().orEmpty().filter { it.name.endsWith(".enc") }) {
            val data=file.readBytes()
            if (data.size < 30 || data[0].toInt()!=1) error("Invalid encrypted data")
            val size=data[1].toInt() and 255
            if (size !in 12..16) error("Invalid IV")
            val iv=data.copyOfRange(2,2+size)
            val cipher=Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE,secret(),GCMParameterSpec(128,iv))
            val decoded=cipher.doFinal(data,2+size,data.size-2-size)
            items.put(JSONObject(String(decoded,Charsets.UTF_8)))
        }
        Base64.encodeToString(items.toString().toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    } catch (_: Exception) { "ERROR" }

    @Synchronized fun delete(id:String):Boolean = try {
        val target=fileFor(id)
        !target.exists() || target.delete()
    } catch (_: Exception) { false }
}
