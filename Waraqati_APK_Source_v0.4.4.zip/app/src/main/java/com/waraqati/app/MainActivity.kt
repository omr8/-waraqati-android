package com.waraqati.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.print.PrintManager
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.widget.Toast

/** Offline exam editor. Same laid-out HTML supplies preview and Android's print adapter. */
class MainActivity : Activity() {
    private companion object {
        const val PICK_IMAGE = 41
        const val APP_URL = "https://appassets.androidplatform.net/assets/index.html"
    }
    private lateinit var web: WebView
    private lateinit var encrypted: EncryptedExamStore
    private var imageCallback: ValueCallback<Array<Uri>>? = null

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        encrypted = EncryptedExamStore(this)
        web = WebView(this)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest): WebResourceResponse =
                if (request.url.toString() == APP_URL)
                    WebResourceResponse("text/html", "UTF-8", assets.open("index.html"))
                else
                    WebResourceResponse("text/plain", "UTF-8", 403, "Forbidden", emptyMap(), "".byteInputStream())
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest): Boolean =
                request.url.toString() != APP_URL
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                imageCallback?.onReceiveValue(null)
                imageCallback = filePathCallback
                return try {
                    startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT)
                        .addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), PICK_IMAGE)
                    true
                } catch (_: Exception) {
                    imageCallback?.onReceiveValue(null)
                    imageCallback = null
                    false
                }
            }
        }
        web.addJavascriptInterface(NativeBridge(), "WaraqatiNative")
        setContentView(web)
        web.loadUrl(APP_URL)
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun printPaper(unused: String, name: String) {
            if (unused.length > 25_000_000) return
            runOnUiThread {
                try {
                    val adapter = web.createPrintDocumentAdapter("ورقتي - " + name.take(80))
                    val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                    manager.print("ورقتي - " + name.take(80), adapter, null)
                } catch (_: Exception) { Toast.makeText(this@MainActivity, "تعذر فتح نافذة الطباعة.", Toast.LENGTH_LONG).show() }
            }
        }
        @JavascriptInterface fun secureLoadAll(): String = encrypted.allBase64()
        @JavascriptInterface fun secureSave(encoded: String): Boolean = encrypted.saveBase64(encoded)
        @JavascriptInterface fun secureDelete(id: String): Boolean = encrypted.delete(id)
    }

    @Deprecated("Legacy back dispatch is needed on minSdk 26")
    override fun onBackPressed() {
        if (!::web.isInitialized) { super.onBackPressed(); return }
        web.evaluateJavascript("(function(){return !!(window.WaraqatiAppBack && window.WaraqatiAppBack());})()") { answer ->
            if (answer != "true") super.onBackPressed()
        }
    }

    @Deprecated("Used for Android 8 and above, no storage permission required")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE) {
            imageCallback?.onReceiveValue(if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null)
            imageCallback = null
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            web.removeJavascriptInterface("WaraqatiNative")
            web.destroy()
        }
        super.onDestroy()
    }
}
