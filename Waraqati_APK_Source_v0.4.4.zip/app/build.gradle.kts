plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.waraqati.app"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.waraqati.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 4
        versionName = "0.4.4"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
